"""Contornos 2D de las carcasas Kynus (mm). Origen = centro de la pantalla, Y hacia arriba."""
import numpy as np
from shapely.geometry import Polygon, Point
from shapely.affinity import translate


def _bezier(p0, c, p1, n=40):
    t = np.linspace(0, 1, n, endpoint=False)[:, None]
    return (1 - t) ** 2 * p0 + 2 * (1 - t) * t * c + t ** 2 * p1


def contorno_estrella():
    """Estrella tipo 'boom' de cómic: 5 puntas de largo y ángulo irregular,
    lados curvados hacia adentro, todas las puntas redondeadas."""
    # (ángulo en grados, radio) de cada punta, empezando por la de arriba
    puntas = [(95, 40.0), (21, 36.5), (-50, 41.0), (-127, 38.0), (160, 38.5)]
    # radio del vértice interno entre cada punta y la siguiente
    internos = [22.5, 24.5, 23.0, 24.0, 22.0]
    # cuánto se curva cada lado hacia adentro (0 = recto)
    curvas = [0.13, 0.02, 0.15, 0.04, 0.12, 0.03, 0.14, 0.02, 0.05, 0.16]
    pts = []
    k = 0
    for i in range(5):
        a0, r0 = puntas[i]
        a1, _ = puntas[(i + 1) % 5]
        if a1 > a0:
            a1 -= 360
        am = (a0 + a1) / 2 + (3 if i % 2 else -3)
        tip = np.array([np.cos(np.radians(a0)), np.sin(np.radians(a0))]) * r0
        nxt = np.array([np.cos(np.radians(a1)), np.sin(np.radians(a1))]) * puntas[(i + 1) % 5][1]
        inner = np.array([np.cos(np.radians(am)), np.sin(np.radians(am))]) * internos[i]
        for p_a, p_b in ((tip, inner), (inner, nxt)):
            mid = (p_a + p_b) / 2
            c = mid * (1 - curvas[k])        # control tirado hacia el centro → lado cóncavo
            pts.append(_bezier(p_a, c, p_b))
            k += 1
    poly = Polygon(np.vstack(pts)).buffer(0)
    # redondeo: puntas (convexas) radio 5, entrantes (cóncavas) radio 4
    poly = poly.buffer(-5, quad_segs=32).buffer(5, quad_segs=32)
    poly = poly.buffer(4, quad_segs=32).buffer(-4, quad_segs=32)
    return poly.simplify(0.01)


def contorno_gota():
    """Gota: círculo abajo, punta redondeada arriba (tangentes rectas)."""
    R, cy = 26.0, -4.0          # círculo de la panza
    tip_y, tip_r = 40.0, 6.0    # punta arriba (redondeada)
    base = Point(0, cy).buffer(R, quad_segs=64)
    punta = Point(0, tip_y).buffer(tip_r, quad_segs=32)
    return base.union(punta).convex_hull.simplify(0.01)


def resample(poly, n=720):
    ring = poly.exterior
    L = ring.length
    pts = np.array([ring.interpolate(L * i / n).coords[0] for i in range(n)])
    # asegurar sentido antihorario
    area = 0.5 * np.sum(pts[:, 0] * np.roll(pts[:, 1], -1) - np.roll(pts[:, 0], -1) * pts[:, 1])
    if area < 0:
        pts = pts[::-1]
    return pts
