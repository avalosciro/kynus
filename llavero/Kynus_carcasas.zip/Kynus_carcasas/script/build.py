"""Genera las carcasas imprimibles de Kynus (estrella y gota) como STL.

Sistema de coordenadas: X derecha, Y arriba, Z = profundidad desde la cara
de la pantalla (z=0) hacia la espalda (z=T). Medidas en mm.
"""
import sys, json
import numpy as np
import manifold3d as m3
from shapely.geometry import Point, Polygon, box, LineString
from shapely.affinity import rotate, translate
import trimesh
import geo

# ---------------- Medidas de componentes (con tolerancia) ----------------
OLED_PCB = (27.9, 28.4)        # módulo SSD1306 0,96" (27,3 x 27,8 real)
VIS_OFF_Y = 1.7                # el área visible está ~1,7 mm arriba del centro de la placa
VENTANA = (26.5, 15.5)         # abertura en el frente (área activa 21,7 x 10,9)
VIDRIO = (27.2, 19.8)          # vidrio del display
ESP = (23.5, 18.6)             # ESP32-C3 Super Mini
TP = (28.5, 17.8)              # TP4056 USB-C
BAT = (32.0, 21.0)             # LiPo 502030
SW = (9.0, 4.0)                # interruptor deslizante SS12D00 (cuerpo)

PARED = 1.8                    # pared lateral
CARA = 1.8                     # espesor del frente y de la espalda
R_BORDE = 3.0                  # radio del redondeo de los bordes
Z_SPLIT = 6.0                  # unión entre frente y tapa
Z_L1 = (CARA, Z_SPLIT)                 # capa OLED
Z_L2 = (Z_SPLIT, Z_SPLIT + 5.2)        # ESP + TP4056
Z_L3 = (Z_L2[1], Z_L2[1] + 5.7)        # batería
T = Z_L3[1] + CARA                     # espesor total
Z_USB = Z_SPLIT + 0.3 + 1.6 + 1.6      # centro del USB-C del TP4056 (placa apoyada sobre el OLED)
AGUJERO_ARO = 4.6

# Pulsador 6x6x5 en la espalda
SW_BOT = dict(cuerpo=6.4, alto=5.0, cap_eje=6.6, cap_ala=8.6, ala=1.0, agujero=7.0, sobresale=1.4)


def cs(poly):
    from shapely.geometry.polygon import orient
    if poly.geom_type == 'MultiPolygon':
        from shapely.geometry import MultiPolygon
        poly = MultiPolygon([orient(p, 1.0) for p in poly.geoms])
    else:
        poly = orient(poly, 1.0)
    if poly.geom_type == 'MultiPolygon':
        return m3.CrossSection([np.array(p.exterior.coords)[:-1] for p in poly.geoms] +
                               [np.array(i.coords)[:-1] for p in poly.geoms for i in p.interiors])
    rings = [np.array(poly.exterior.coords)[:-1]] + [np.array(i.coords)[:-1] for i in poly.interiors]
    return m3.CrossSection(rings)


def prisma(poly, z0, z1):
    return m3.Manifold.extrude(cs(poly), z1 - z0).translate((0, 0, z0))


def rect(w, h, cx=0, cy=0, ang=0):
    return translate(rotate(box(-w / 2, -h / 2, w / 2, h / 2), ang, origin=(0, 0)), cx, cy)


def rrect(w, h, r, cx=0, cy=0, ang=0):
    return translate(rotate(box(-w / 2 + r, -h / 2 + r, w / 2 - r, h / 2 - r).buffer(r, quad_segs=16), ang, origin=(0, 0)), cx, cy)


def cuerpo_redondeado(outline, T, r=R_BORDE, nz_r=14):
    """Sólido con el contorno dado y bordes redondeados (cuarto de círculo) arriba y abajo."""
    pts = geo.resample(outline, 900)
    d = np.roll(pts, -1, 0) - np.roll(pts, 1, 0)
    n = np.stack([d[:, 1], -d[:, 0]], 1)
    n /= np.linalg.norm(n, axis=1, keepdims=True)
    for _ in range(3):  # suavizar normales
        n = (np.roll(n, 1, 0) + 2 * n + np.roll(n, -1, 0))
        n /= np.linalg.norm(n, axis=1, keepdims=True)
    ang = np.linspace(0, np.pi / 2, nz_r)
    zs, offs = [], []
    for a in ang:                       # borde del frente
        zs.append(r - r * np.sin(a)); offs.append(r - r * np.cos(a))
    zs = zs[::-1]; offs = offs[::-1]
    for a in ang:                       # borde de la espalda
        zs.append(T - r + r * np.sin(a)); offs.append(r - r * np.cos(a))
    N = len(pts)
    verts = []
    for z, o in zip(zs, offs):
        ring = pts - n * o
        verts.append(np.column_stack([ring, np.full(N, z)]))
    verts = np.vstack(verts)
    tris = []
    L = len(zs)
    for k in range(L - 1):
        a0, b0 = k * N, (k + 1) * N
        for i in range(N):
            j = (i + 1) % N
            tris.append((a0 + i, a0 + j, b0 + j))
            tris.append((a0 + i, b0 + j, b0 + i))
    # tapas
    cap0 = m3.triangulate([verts[:N, :2]])
    for t in cap0:
        tris.append((t[0], t[2], t[1]))
    off = (L - 1) * N
    capT = m3.triangulate([verts[off:off + N, :2]])
    for t in capT:
        tris.append((off + t[0], off + t[1], off + t[2]))
    mesh = m3.Mesh(vert_properties=verts.astype(np.float32), tri_verts=np.array(tris, dtype=np.uint32))
    s = m3.Manifold(mesh)
    assert s.status() == m3.Error.NoError, s.status()
    return s


def cilindro(r, z0, z1, x, y, seg=48):
    return m3.Manifold.cylinder(z1 - z0, r, r, seg).translate((x, y, z0))


def construir(nombre, outline, cfg):
    cav2d = outline.buffer(-PARED)
    plano = outline.buffer(-R_BORDE)           # zona plana de frente y espalda
    ox, oy = cfg['oled']                        # centro de la ventana
    pcb_c = (ox, oy - VIS_OFF_Y)
    ax, ay = cfg['aro']
    bx, by = cfg['boton']

    # ---------- huellas de componentes por capa ----------
    huellas = {
        'L1': [('OLED', rect(*OLED_PCB, *pcb_c))],
        'L2': [('ESP32-C3', rect(*ESP, cfg['esp'][1], cfg['esp'][2], cfg['esp'][0])),
               ('TP4056', rect(*TP, cfg['tp'][1], cfg['tp'][2], cfg['tp'][0]))],
        'L3': [('Bateria', rect(*BAT, cfg['bat'][1], cfg['bat'][2], cfg['bat'][0]))],
    }
    # alojamiento del pulsador (L3 y parte de L2) y columna que lo sostiene (L1-L2)
    s = SW_BOT
    z_in = T - CARA
    z_sw_bot = z_in - s['ala'] - s['alto']
    bolsillo = Point(bx, by).buffer(s['cap_ala'] / 2 + 0.4 + 1.2)
    columna = rect(4.5, 4.5, bx, by)
    reservas = {'L1': [('columna boton', columna)],
                'L2': [('columna boton', columna)] + ([('bolsillo boton', bolsillo)] if z_sw_bot < Z_L2[1] else []),
                'L3': [('bolsillo boton', bolsillo)]}
    aro_res = Point(ax, ay).buffer(AGUJERO_ARO / 2 + 2.0)

    problemas = []
    for capa, lista in huellas.items():
        for nom, h in lista:
            if not cav2d.difference(aro_res).contains(h):
                problemas.append(f'{nom} se sale de la cavidad')
            for nom2, r in reservas[capa]:
                if h.intersects(r):
                    problemas.append(f'{nom} choca con {nom2} ({h.intersection(r).area:.1f} mm²)')
        for (n1, h1), (n2, h2) in [(a, b) for i, a in enumerate(lista) for b in lista[i + 1:]]:
            if h1.buffer(0.4).intersects(h2):
                problemas.append(f'{n1} choca con {n2}')

    # ---------- tornillos: buscar 2 lugares libres en todas las capas ----------
    ocupado = aro_res.union(bolsillo).union(columna)
    for capa in huellas:
        for _, h in huellas[capa]:
            ocupado = ocupado.union(h)
    zona_tor = plano.buffer(-2.6).difference(ocupado.buffer(3.2))
    cands = []
    xs = np.arange(-35, 35, 0.5)
    for x in xs:
        for y in np.arange(-35, 50, 0.5):
            if zona_tor.contains(Point(x, y)):
                cands.append((x, y))
    cands = np.array(cands)
    if len(cands) < 2:
        problemas.append('no hay lugar para 2 tornillos')
        tornillos = []
    else:
        # par más separado
        dmat = np.linalg.norm(cands[:, None] - cands[None], axis=2)
        i, j = np.unravel_index(np.argmax(dmat), dmat.shape)
        tornillos = [tuple(cands[i]), tuple(cands[j])]

    # ---------- interruptor deslizante: lugar sobre la pared en L3 ----------
    ocup_L3 = huellas['L3'][0][1].union(bolsillo).union(aro_res)
    for tx, ty in tornillos:
        ocup_L3 = ocup_L3.union(Point(tx, ty).buffer(2.8))
    from shapely.geometry.polygon import orient
    ring = orient(cav2d, 1.0).exterior
    mejor_sw = None
    for k in range(0, 400):
        p = ring.interpolate(ring.length * k / 400)
        q = ring.interpolate(ring.length * ((k + 1) % 400) / 400)
        t = np.array([q.x - p.x, q.y - p.y]); t /= np.linalg.norm(t)
        nin = np.array([-t[1], t[0]])            # normal hacia adentro (contorno antihorario)
        c = np.array([p.x, p.y]) + nin * (SW[1] / 2 + 0.2)
        ang = np.degrees(np.arctan2(t[1], t[0]))
        r = rect(*SW, c[0], c[1], ang)
        if cav2d.buffer(0.3).contains(r) and not r.buffer(0.6).intersects(ocup_L3):
            m = r.distance(ocup_L3)
            if mejor_sw is None or m > mejor_sw[0]:
                mejor_sw = (m, (p.x, p.y), ang, nin)
    if mejor_sw is None:
        problemas.append('no entra el interruptor')

    # ---------- sólidos ----------
    cuerpo = cuerpo_redondeado(outline, T)
    cav = prisma(cav2d.difference(aro_res), CARA, T - CARA)
    # columnas de tornillo
    for tx, ty in tornillos:
        cav = cav - cilindro(2.8, 0, T, tx, ty)
    shell = cuerpo - cav

    # ventana con bisel (más grande afuera)
    ven = m3.Manifold.extrude(cs(rrect(*VENTANA, 1.5)), CARA + 0.02, scale_top=((VENTANA[0] - 2.4) / VENTANA[0], (VENTANA[1] - 2.4) / VENTANA[1]))
    ven = ven.translate((0, 0, -0.01))
    # extrude escala alrededor del origen: lo armamos centrado en 0 y lo movemos
    ven = ven.translate((ox, oy, 0))
    shell = shell - ven
    # agujero del aro (pasante) con chaflanes
    shell = shell - cilindro(AGUJERO_ARO / 2, -1, T + 1, ax, ay)
    for z0, z1, r0, r1 in ((-0.01, 0.8, AGUJERO_ARO / 2 + 0.8, AGUJERO_ARO / 2), (T - 0.8, T + 0.01, AGUJERO_ARO / 2, AGUJERO_ARO / 2 + 0.8)):
        shell = shell - m3.Manifold.cylinder(z1 - z0, r0, r1, 48).translate((ax, ay, z0))

    # ---------- FRENTE ----------
    medio = m3.Manifold.cube((300, 300, Z_SPLIT)).translate((-150, -150, 0))
    frente = shell ^ medio
    # rebaje interno para el encastre (la tapa entra adentro)
    reb = outline.buffer(-0.9).difference(cav2d)
    frente = frente - prisma(reb, Z_SPLIT - 1.6, Z_SPLIT + 0.1)
    # marco que ubica el OLED: alojamiento de la placa y del vidrio
    marco = rect(OLED_PCB[0] + 2.4, OLED_PCB[1] + 2.4, *pcb_c).intersection(cav2d.buffer(-0.3))
    frente = frente + (prisma(marco, CARA, CARA + 3.0) - prisma(rect(*OLED_PCB, *pcb_c), CARA + 1.4, CARA + 3.1)
                       - prisma(rect(*VIDRIO, ox, oy - 2.0), CARA - 0.01, CARA + 1.45))
    # dejar pasar cables por arriba del marco (ranura)
    frente = frente - prisma(rect(16, 3.0, pcb_c[0], pcb_c[1] + OLED_PCB[1] / 2 + 0.6), CARA + 1.4, CARA + 3.1)
    frente = frente - ven
    # columna que sostiene el pulsador
    frente = frente + prisma(columna, CARA - 0.01, z_sw_bot)
    # pilotos de tornillo
    for tx, ty in tornillos:
        frente = frente - cilindro(0.8, 2.2, Z_SPLIT + 0.1, tx, ty, 24)

    # ---------- TAPA (espalda) ----------
    resto = m3.Manifold.cube((300, 300, T + 2 - Z_SPLIT)).translate((-150, -150, Z_SPLIT))
    tapa = shell ^ resto
    pestana = outline.buffer(-0.9 - 0.15).difference(cav2d)
    tapa = tapa + prisma(pestana, Z_SPLIT - 1.5, Z_SPLIT + 0.01)
    for tx, ty in tornillos:
        tapa = tapa - cilindro(1.2, Z_SPLIT - 2, T + 1, tx, ty, 24)
        tapa = tapa - cilindro(2.2, T - 2.2, T + 1, tx, ty, 32)          # cabeza embutida
    # USB-C del TP4056
    ang, cx, cy = cfg['tp']
    a = np.radians(ang)
    px, py = cx + np.cos(a) * TP[0] / 2, cy + np.sin(a) * TP[0] / 2
    usb = m3.Manifold.extrude(cs(rrect(10.0, 4.2, 1.9)), 8.0)               # en XY, luego lo paramos
    usb = usb.translate((0, 0, -4.0)).rotate((90, 0, 0))                     # ahora: ancho en X, alto en Z, largo en Y
    usb = usb.rotate((0, 0, ang - 90)).translate((px, py, Z_USB))
    tapa = tapa - usb
    # interruptor deslizante: ranura en la pared
    if mejor_sw:
        _, (sx, sy), sang, nin = mejor_sw
        zc = (Z_L3[0] + Z_L3[1]) / 2
        ran = m3.Manifold.extrude(cs(rrect(5.6, 2.4, 0.9)), 8.0).translate((0, 0, -4.0)).rotate((90, 0, 0))
        ran = ran.rotate((0, 0, sang)).translate((sx - nin[0] * 0.5, sy - nin[1] * 0.5, zc))
        tapa = tapa - ran
    # alojamiento del pulsador (cuelga de la espalda)
    tubo_ext = rect(s['cuerpo'] + 2.4, s['cuerpo'] + 2.4, bx, by).union(Point(bx, by).buffer(s['cap_ala'] / 2 + 0.4 + 1.2))
    tapa = tapa + prisma(tubo_ext.intersection(cav2d), z_sw_bot + 0.6, z_in + 0.01)
    tapa = tapa - prisma(rect(s['cuerpo'], s['cuerpo'], bx, by), z_sw_bot - 1, z_in - s['ala'] + 0.01)
    tapa = tapa - cilindro(s['cap_ala'] / 2 + 0.4, z_in - s['ala'] - 0.2, z_in + 0.01, bx, by)
    tapa = tapa - cilindro(s['agujero'] / 2, z_in - 0.1, T + 1, bx, by)
    # ventanita en el tubo para sacar los cables del pulsador
    tapa = tapa - prisma(rect(s['cuerpo'] + 3, 3.0, bx, by), z_sw_bot - 1, z_sw_bot + 2.0)

    # ---------- BOTÓN (tecla) ----------
    tecla = (m3.Manifold.cylinder(s['ala'] - 0.15, s['cap_ala'] / 2, s['cap_ala'] / 2, 64)
             + m3.Manifold.cylinder(CARA + s['sobresale'] - 0.4, s['cap_eje'] / 2, s['cap_eje'] / 2, 64).translate((0, 0, s['ala'] - 0.15))
             + m3.Manifold.sphere(s['cap_eje'] / 2, 64).scale((1, 1, 0.35)).translate((0, 0, s['ala'] - 0.15 + CARA + s['sobresale'] - 0.4)))

    info = dict(T=round(T, 2), tornillos=[tuple(round(v, 1) for v in t) for t in tornillos],
                interruptor=(tuple(round(v, 1) for v in mejor_sw[1]), round(mejor_sw[2])) if mejor_sw else None,
                problemas=problemas, ancho=round(outline.bounds[2] - outline.bounds[0], 1),
                alto=round(outline.bounds[3] - outline.bounds[1], 1))
    return dict(frente=frente, tapa=tapa, tecla=tecla, info=info, huellas=huellas, outline=outline,
                tornillos=tornillos)


def a_trimesh(mf):
    m = mf.to_mesh()
    return trimesh.Trimesh(vertices=np.array(m.vert_properties)[:, :3], faces=np.array(m.tri_verts), process=False)


CONFIGS = {
    'estrella': dict(outline=geo.contorno_estrella,
                     oled=(0.0, 1.7), aro=(-2.45, 26.4), boton=(-13.6, -18.4),
                     esp=(110, -12.0, 2.0), tp=(258, 11.5, -8.5), bat=(168, 2.0, -1.0)),
    'gota': dict(outline=geo.contorno_gota,
                 oled=(0.0, -1.3), aro=(0.0, 38.5), boton=(0.0, 25.5),
                 esp=(20, 3.0, -13.0), tp=(24, 3.5, 10.0), bat=(90, 0.0, -3.0)),
}

if __name__ == '__main__':
    nombre = sys.argv[1]
    cfg = CONFIGS[nombre]
    r = construir(nombre, cfg['outline'](), cfg)
    print(json.dumps(r['info'], ensure_ascii=False, indent=1))
    if '--stl' in sys.argv:
        import os
        os.makedirs('stl', exist_ok=True)
        for parte in ('frente', 'tapa', 'tecla'):
            mf = r[parte]
            if parte == 'tapa':      # imprimir con la espalda sobre la cama
                mf = mf.mirror((0, 0, 1)).translate((0, 0, T))
            tm = a_trimesh(mf.simplify(0.002))
            b = tm.bounds
            tm.apply_translation((0, 0, -b[0][2]))
            print(parte, 'watertight:', tm.is_watertight, 'vol cm3:', round(tm.volume / 1000, 2), 'tam:', np.round(tm.extents, 1))
            tm.export(f'stl/kynus_{nombre}_{parte}.stl')
